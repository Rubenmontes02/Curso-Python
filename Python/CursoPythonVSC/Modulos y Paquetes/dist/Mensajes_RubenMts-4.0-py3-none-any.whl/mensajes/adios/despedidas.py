def despedir():
    print('Adios, me despido desde despedidas.despedir()')

class Despedir:
    def __init__(self):
        print('Adios, me despido desde Despedir __init__')
def saludar():
    print('hola, te saludo desde saludos.saludar()')

def prueba():
    print('Prueba de la nueva version')

    
class Saludo:
    def __init__(self):
        print('Hola, te saludo desde Saludo__init__')



if __name__ == '__main__':
    saludar()